# phenoRankeR 0.0.0.9001

* Added a `NEWS.md` file to track changes to the package.
