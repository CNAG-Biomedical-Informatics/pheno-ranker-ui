Examples taken from:

csv conversion:
https://www.kaggle.com/datasets/alphiree/cardiovascular-diseases-risk-prediction-dataset
Note: we only used the first 25 rows of the dataset and the first 11 columns for the example.

Individual/Cohort comparison:
Test data to make sure that an error is thrown when there are more than 1000 individuals in the cohort
has been generated using pheno-ranker/sim/create_random_bff_pxf.pl

Filename: more_than_1000_individuals.bff.json