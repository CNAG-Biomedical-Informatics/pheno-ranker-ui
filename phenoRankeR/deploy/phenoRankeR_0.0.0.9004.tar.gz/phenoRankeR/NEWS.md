# phenoRankeR 0.0.0.9004

* Added a `NEWS.md` file to track changes to the package.
