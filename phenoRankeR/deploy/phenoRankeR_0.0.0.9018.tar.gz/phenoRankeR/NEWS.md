# phenoRankeR 0.0.0.9018

* Added a `NEWS.md` file to track changes to the package.
