# phenoRankeR 0.0.0.9019

* Added a `NEWS.md` file to track changes to the package.
