not_working_patient.json
is causing the following error when uploading it
Warning: Error in parse_con: parse error: trailing garbage
          "label" : "male"       }    },    {       "ethnicity" : {
                     (right here) ------^

TODO
This error needs to be catched by R-Shiny