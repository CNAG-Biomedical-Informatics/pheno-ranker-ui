color palette: 
https://loading.io/color/feature/Spectral-11/

id color is from here:
https://www.flatuicolorpicker.com/grey-rgba-color-model/
Silver Sand